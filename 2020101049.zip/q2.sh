#!/bin/bash
declare dd
declare mm
declare yyyy
declare len
declare name
file="$1"
while read p 
do
    len=${#p}
    name=${p:0:len-11}
    printf "$name" >> q2_output.txt
    d=${p:len-11:2}
    m=${p:len-8:2}
    y=${p:len-5:4}
    yy=`date "+%Y"`
mm=`date "+%m"`
dd=`date "+%d"`
if [ $y -le $yy ]
then
yyy=`expr $yy - $y`
mmm=`expr $mm - $m`
#ddd=`expr $dd - $d`
if [ $m -gt $mm ]
then
yyy=`expr $yyy - 1`
mmm=`expr $mmm + 12`
fi
if [ $d -gt $dd ]
then
ddd=`expr $d - $dd`
ddd=`expr 31 - $ddd`
else
ddd=`expr $dd - $d`
fi
fi
    echo "$yyy" >> q2_output.txt
done < $file