#!/bin/bash
file="data.csv"
while getopts 'C:f:l:n:o:k:adc:v:' flag; do
  case "${flag}" in
    C) com=$OPTARG ;;
    f) fnam=$OPTARG ;;
    l) lnam=$OPTARG ;;
    n) no=$OPTARG ;;
    o) cop=$OPTARG ;;
    k) fna=$OPTARG ;;
    a) ;;
    d) ;;
    c) ;;
    v) ;;
    *) exit 1 ;;
  esac
done
if [ "$com" == "insert" ]
then
{
    echo "$fnam,$lnam,$no,$cop" >> data.csv
}    
fi
if [ "$com" == "edit" ]
then
{
    awk '/^$fna/ {$fnam FS $lnam FS $no FS $cop}' data.csv
}
fi
#if [ "$com" == "display" ]
#then
#{

#}
#fi
#if [ "$com" == "search" ]
#then
#{

#}
#fi
#if [ "$com" == "delete" ]
#then
#{
#}
#fi