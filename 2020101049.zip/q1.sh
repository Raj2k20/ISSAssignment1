#!/bin/bash
cat "$1" | while read line || [ -n "$line" ]
do
    printf "${line:0:4}" >> "q1_output.txt"
    i=5
    while ((i++<${#line}))
    do
        printf "#" >> "q1_output.txt"
    done
    printf "\n" >> "q1_output.txt"
done