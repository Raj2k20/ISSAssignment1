#!/bin/bash

clear

file="$1"

grep -o  '\bs[^a]\w*' "$file"
grep -o  '\bwh\w*' "$file"
grep -o  '\bth\w*' "$file"
grep -o  '\ba[^n]\w*' "$file"